package com.dbs.article.usecase

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.dbs.article.data.Article
import com.dbs.article.model.Response
import com.dbs.article.model.Response.Error
import com.dbs.article.repository.ArticleRespository
import io.reactivex.functions.Cancellable
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlin.coroutines.CoroutineContext
import com.dbs.article.model.Result
import com.uob.mighty.lifestyle.model.UseCaseWithOutParameter

class ArticleViewModelUsecase(private val articleRespository: ArticleRespository):
    UseCaseWithOutParameter<LiveData<Result<List<Article>>>>,
    Cancellable,
    CoroutineScope {

    private var job: Job? = null
    override val coroutineContext: CoroutineContext
        get() = Dispatchers.IO

    override fun execute(): LiveData<Result<List<Article>>> {
        val result = MutableLiveData<Result<List<Article>>>()
        result.postValue(Result.Loading)
        job = launch {
            val toPost = when (val response =
                articleRespository.getArticle()) {
                is Response.Success -> {
                    Result.Success(response.data)
                }
                is Response.Failure -> {
                    Result.Failure(response.failure)
                }
                is Error -> {
                    Result.Error(response.exception)
                }
            }
            result.postValue(toPost)
        }
        return result
    }

        override fun cancel() {
            job?.cancel()
        }
}