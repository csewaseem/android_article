package com.dbs.article

import android.app.Application
import com.dbs.article.di.article
import org.koin.android.ext.koin.androidContext
import org.koin.android.ext.koin.androidLogger
import org.koin.core.context.startKoin

class ArticleApp: Application() {
    override fun onCreate() {
        super.onCreate()

        startKoin {
            androidLogger()
            // Android context
            androidContext(this@ArticleApp)
            // modules
            modules(listOf(article))
        }
    }
}