package com.dbs.article.repository

import com.dbs.article.data.Article
import com.dbs.article.model.Response
import retrofit2.Call
import retrofit2.await

class ArticleRespository constructor(private val weatherRepositoryService: ArticleRepositoryService) {

    suspend fun getArticle(): Response<List<Article>> {
        return try {
            val result = getArticleAPI().await()
            with(result) {
                Response.Success(this)
            }
        } catch (e: Exception) {
            Response.Error(e)
        }
    }

    private fun getArticleAPI(): Call<List<Article>> {
        return weatherRepositoryService.getArticle()
    }

}
