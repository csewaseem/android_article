package com.dbs.article.ui

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.navigation.Navigation
import androidx.recyclerview.widget.LinearLayoutManager
import com.dbs.article.R
import com.dbs.article.adapter.ArticleAdapter
import com.dbs.article.data.Article
import com.dbs.article.data.Constants
import com.dbs.article.data.Event
import com.dbs.article.viewmodel.ArticleViewModel
import kotlinx.android.synthetic.main.article_fragment.*
import kotlinx.android.synthetic.main.header.*
import org.koin.android.viewmodel.ext.android.sharedViewModel
import com.dbs.article.model.*
import com.dbs.article.utils.ArticleUtils
import kotlinx.android.synthetic.main.article_fragment.progressBar

class ArticleFragment : Fragment() {

    private lateinit var mActivity: ArticleActivity
    private val viewModel: ArticleViewModel by sharedViewModel()
    lateinit var articleItemAdapter: ArticleAdapter
    private lateinit var rootView: View
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
         rootView = inflater.inflate(R.layout.article_fragment, container, false)
        return rootView
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        mActivity = activity as ArticleActivity

        setUpToolbar()
        getArticleList()
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewModel.articleDataEventTrigger.postValue(Event(Unit))
    }

    private fun getArticleList() {
        showLoader()
        viewModel.articleDataEventTriggerEvent.observe(mActivity, articleDataObserver)
    }

    @SuppressLint("WrongConstant")
    private fun weatherAdapter(weatherList: List<Article>?) {
        val linearLayoutManager = LinearLayoutManager(mActivity)
        linearLayoutManager.orientation = LinearLayoutManager.VERTICAL
        recycleArticle.setLayoutManager(linearLayoutManager)
        articleItemAdapter = ArticleAdapter(mActivity, weatherList ?: listOf())
        articleItemAdapter.setOnItemClickListener(object : ArticleAdapter.OnItemClickListener {
            override fun onClick(view: View, data: Article) {
                goToArticleDetailsFragment(data)
            }
        })
        recycleArticle.adapter = articleItemAdapter
        articleItemAdapter.notifyDataSetChanged()
    }

    private fun setUpToolbar() {
        mActivity?.setSupportActionBar(toolbar)
        mActivity?.supportActionBar?.title = getString(R.string.app_name)
        mActivity?.supportActionBar?.setDisplayHomeAsUpEnabled(true)
        mActivity?.supportActionBar?.setDisplayShowHomeEnabled(true)
        toolbar.setNavigationIcon(R.drawable.ic_close)
        toolbar.setNavigationOnClickListener {
            mActivity?.onBackPressed()
        }
    }

    private fun goToArticleDetailsFragment(data: Article) {
        val bundle = Bundle()
        bundle.putSerializable(Constants.ARTICLE, data)
        Navigation.findNavController(rootView).navigate(R.id.articleDetailsFragment, bundle)
    }

    val articleDataObserver = Observer<Result<List<Article>?>> {
        if (it is Result.Loading) {

        } else {
            if (it is Result.Success) {
                weatherAdapter(it?.data)
                hideLoader()
            }
            if (it is Result.Error) {
                hideLoader()
                ArticleUtils.handleError(mActivity, it?.exception)
            }
            if (it is Result.Failure) {
                hideLoader()
            }
        }
    }

    private fun hideLoader() {
        progressBar?.visibility = View.GONE
    }

    private fun showLoader() {
        progressBar?.visibility = View.VISIBLE
    }

}