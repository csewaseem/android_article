package com.dbs.article.data

import java.io.Serializable

data class Article (
    val id : Int,
    val title : String,
    val last_update : Long,
    val short_description : String,
    val avatar : String,
override val error: List<Error>?
): ResponseData, Serializable