package com.dbs.article.di

import android.content.Context
import com.dbs.article.repository.ArticleDetailsRespository
import com.dbs.article.repository.ArticleServicesHelper
import com.dbs.article.repository.ArticleRepositoryService
import com.dbs.article.repository.ArticleRespository
import com.dbs.article.usecase.ArticleDetailViewModelUsecase
import com.dbs.article.usecase.ArticleViewModelUsecase
import com.dbs.article.viewmodel.ArticleDetailsViewModel
import com.dbs.article.viewmodel.ArticleViewModel
import org.koin.android.ext.koin.androidApplication
import org.koin.android.ext.koin.androidContext
import org.koin.android.viewmodel.dsl.viewModel
import org.koin.dsl.module

val article = module {
    single { provideArticleServicesAPI(androidContext()) }
    single { ArticleRespository(get()) }
    single { ArticleDetailsRespository(get()) }
    single { ArticleViewModelUsecase(get()) }
    single { ArticleDetailViewModelUsecase(get()) }
    viewModel { ArticleViewModel(androidApplication()) }
    viewModel { ArticleDetailsViewModel(androidApplication()) }
}

fun provideArticleServicesAPI(context: Context): ArticleRepositoryService {

    return ArticleServicesHelper(context).createTransactRetrofit()
}