package com.uob.mighty.lifestyle.model

/**
 *
 */
interface UseCase<out R> {
    fun execute(): R
}

interface UseCaseWithParameter<P, R> {
    fun execute(parameter: P): R
}

interface UseCaseWithOutParameter< R> {
    fun execute(): R
}

interface Cancellable {
    fun cancel()
}