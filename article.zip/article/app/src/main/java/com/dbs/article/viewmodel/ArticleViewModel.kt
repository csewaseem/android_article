package com.dbs.article.viewmodel

import android.app.Application
import androidx.lifecycle.*
import com.dbs.article.data.*
import com.dbs.article.usecase.ArticleViewModelUsecase
import org.koin.core.KoinComponent
import org.koin.core.inject
import com.dbs.article.model.Result

class ArticleViewModel(application: Application) : ViewModel(), KoinComponent {

    private val articleViewModelUsecase: ArticleViewModelUsecase by inject()

    internal val articleDataEventTrigger = MutableLiveData<Event<Unit>>()

    val articleDataEventTriggerEvent: LiveData<Result<List<Article>>> =
        Transformations.switchMap(articleDataEventTrigger) {
            it.getContentIfNotHandled()?.let {
                articleViewModelUsecase.execute()
            }
        }
}