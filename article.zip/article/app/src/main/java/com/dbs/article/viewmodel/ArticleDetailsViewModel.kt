package com.dbs.article.viewmodel

import android.app.Application
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Transformations
import androidx.lifecycle.ViewModel
import com.dbs.article.data.Article
import com.dbs.article.data.ArticleDetails
import com.dbs.article.data.Event
import com.dbs.article.model.Result
import com.dbs.article.usecase.ArticleDetailViewModelUsecase
import org.koin.core.KoinComponent
import org.koin.core.inject

class ArticleDetailsViewModel(application: Application): ViewModel(), KoinComponent {

    var articleId : String = ""
    var selectedArticle : Article? = null

    var articleDetails  : ArticleDetails? = null

    private val articleDetailsViewModelUsecase: ArticleDetailViewModelUsecase by inject()

    internal val articleDetailsDataEventTrigger = MutableLiveData<Event<Unit>>()

    val articleDetaisDataEventTriggerEvent: LiveData<Result<ArticleDetails>> =
        Transformations.switchMap(articleDetailsDataEventTrigger) {
            it.getContentIfNotHandled()?.let {
                articleDetailsViewModelUsecase.execute(selectedArticle?.id ?:0)
            }
        }

    fun selectArticle(article: Article) {
        selectedArticle = article
    }

    fun updateArticleDetails(article: ArticleDetails?){
        articleDetails = article
    }

}