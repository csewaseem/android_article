package com.dbs.article.ui

import android.os.Bundle
import android.view.*
import com.dbs.article.R
import com.dbs.article.data.ArticleDetails
import com.dbs.article.data.Constants
import com.dbs.article.viewmodel.ArticleDetailsViewModel
import kotlinx.android.synthetic.main.article_details_edit_fragment.*
import kotlinx.android.synthetic.main.header.*
import org.koin.android.viewmodel.ext.android.sharedViewModel

class ArticleDetailsEditFragment : BaseFragment() {

    private lateinit var mActivity: ArticleActivity
    private val viewModel: ArticleDetailsViewModel by sharedViewModel()
    private lateinit var rootView: View

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        rootView = inflater.inflate(R.layout.article_details_edit_fragment, container, false)
        setHasOptionsMenu(true)
        return rootView
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        mActivity = activity as ArticleActivity
        setBundle()
        setUpToolbar()
        editDescription()
        setSaveListener()
    }

    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        inflater?.inflate(R.menu.menu_cancel, menu)
        super.onCreateOptionsMenu(menu, inflater)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val id = item?.itemId
        when (id) {
            R.id.cancel -> {
                mActivity?.onBackPressed()
                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }

    private fun setBundle() {
        val articleDetails = bundle.getSerializable(Constants.ARTICLE_DETAILS) ?: ""
        if (articleDetails != null) {
            articleDetails as ArticleDetails
            viewModel.updateArticleDetails(articleDetails)
        }
    }

    private fun editDescription() {
        editDescription.setText(viewModel.articleDetails?.text)
    }

    private fun setSaveListener() {
        save.setOnClickListener {
            mActivity?.onBackPressed()
        }
    }

    private fun setUpToolbar() {
        mActivity?.setSupportActionBar(toolbar)
        mActivity?.supportActionBar?.title = viewModel.selectedArticle?.title ?:"Title"
        mActivity?.supportActionBar?.setDisplayHomeAsUpEnabled(true)
        mActivity?.supportActionBar?.setDisplayShowHomeEnabled(true)
        toolbar.setNavigationIcon(R.drawable.ic_back_arrow)
        toolbar.setNavigationOnClickListener {
            mActivity?.onBackPressed()
        }
    }
}