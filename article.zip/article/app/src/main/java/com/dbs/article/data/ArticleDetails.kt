package com.dbs.article.data

import java.io.Serializable

data class ArticleDetails (
    val id : Int,
    val text : String,
    override val error: List<Error>?
): ResponseData, Serializable