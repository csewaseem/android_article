package com.dbs.article.ui

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.fragment.NavHostFragment
import com.dbs.article.R
import kotlinx.android.synthetic.main.activity_article.*

class ArticleActivity : AppCompatActivity() {

    private lateinit var mNavHostFragment: NavHostFragment

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_article)
        mNavHostFragment = supportFragmentManager.findFragmentById(R.id.article_navHostFragment) as NavHostFragment
    }

    override fun onSupportNavigateUp() =
        NavHostFragment.findNavController(article_navHostFragment).navigateUp()
}