package com.dbs.article.utils

import android.content.Context
import android.util.Log
import com.dbs.article.R
import com.dbs.article.data.Constants.CONNECTION_TIMEOUT
import java.text.SimpleDateFormat
import java.util.*

object ArticleUtils {

    fun formatSystemDate(systemDate: Long, format: String): String {
        return try {
            val formatter = SimpleDateFormat(format, Locale.ENGLISH)
            val calendar = Calendar.getInstance()
            calendar.timeInMillis = systemDate
            formatter.format(calendar.time)
        } catch (e: Exception) {
            Log.e("Format date", e.message)
            ""
        }
    }

    fun handleError(context: Context, articleError: Exception, callback: (() -> Unit)? = null) {
        val isTimeOut = articleError.message == CONNECTION_TIMEOUT
        var title = context.getString(R.string.error)
        var message = articleError.message ?: ""
        if (isTimeOut) {
            title = context.getString(R.string.subheadConnectionError)
            message = context.getString(R.string.bodycopyConnectionError)
            ArticleDialog.showConfirmDialog(context, title, message)
        } else {
            if (callback != null) {
                callback()
            } else {
                ArticleDialog.showConfirmDialog(
                    context,
                    context.getString(R.string.error),
                    context.getString(R.string.generic_error_message)
                )
            }
        }

    }
}