package com.dbs.article.data

object Constants {

    const val ERROR_MESSAGE = "We are unable to process your request. For assistance, call"

    const val BASE_URL: String = "https://task.free.beeceptor.com"

    const val NETWORK_CALL_TIMEOUT = 60

    const val ARTICLE = "ARTICLE"
    const val ARTICLE_DETAILS = "ARTICLE_DETAILS"

    const val CONNECTION_TIMEOUT = "We are unable to connect. You can check your connection or try again later."
}