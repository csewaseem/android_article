package com.dbs.article.model

import com.dbs.article.data.Constants.ERROR_MESSAGE


data class ArticleError(val errorMessage: String? = ERROR_MESSAGE) {

    companion object {
        private fun getErrorMessage(errorMessage: String?): String? {
            return errorMessage
        }
    }

    var message: String? = ""
        get() = getErrorMessage(errorMessage)

}