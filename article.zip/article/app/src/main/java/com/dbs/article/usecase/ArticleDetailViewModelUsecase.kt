package com.dbs.article.usecase

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.dbs.article.data.ArticleDetails
import com.dbs.article.model.Response
import com.dbs.article.model.Result
import com.dbs.article.repository.ArticleDetailsRespository
import com.uob.mighty.lifestyle.model.Cancellable
import com.uob.mighty.lifestyle.model.UseCaseWithParameter
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlin.coroutines.CoroutineContext

class ArticleDetailViewModelUsecase(private val articleDetailsRespository: ArticleDetailsRespository) :
    UseCaseWithParameter<Int, LiveData<Result<ArticleDetails>>>,
    Cancellable,
    CoroutineScope {

    private var job: Job? = null
    override val coroutineContext: CoroutineContext
        get() = Dispatchers.IO

    override fun execute(parameter : Int): LiveData<Result<ArticleDetails>> {
        val result = MutableLiveData<Result<ArticleDetails>>()
        val request = (parameter)
        result.postValue(Result.Loading)
        job = launch {
            val toPost = when (val response =
                articleDetailsRespository.getArticleDetails(request)) {
                is Response.Success -> {
                    Result.Success(response.data)
                }
                is Response.Failure -> {
                    Result.Failure(response.failure)
                }
                is Response.Error -> {
                    Result.Error(response.exception)
                }
            }
            result.postValue(toPost)
        }
        return result
    }

    override fun cancel() {
        job?.cancel()
    }

}