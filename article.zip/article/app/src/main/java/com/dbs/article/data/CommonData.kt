package com.dbs.article.data


data class Error (
    val msg : String
)

interface ResponseData{
    val error: List<Error>?
}
