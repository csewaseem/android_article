package com.dbs.article.ui

import android.os.Bundle
import android.view.*
import androidx.lifecycle.Observer
import androidx.navigation.Navigation
import com.dbs.article.R
import com.dbs.article.data.Article
import com.dbs.article.data.ArticleDetails
import com.dbs.article.data.Constants
import com.dbs.article.data.Event
import com.dbs.article.extension.setBannerImageUrl
import com.dbs.article.model.Result
import com.dbs.article.utils.ArticleUtils
import com.dbs.article.viewmodel.ArticleDetailsViewModel
import kotlinx.android.synthetic.main.article_details_fragment.*
import kotlinx.android.synthetic.main.header.*
import org.koin.android.viewmodel.ext.android.sharedViewModel

class ArticleDetailsFragment : BaseFragment() {

    private lateinit var mActivity: ArticleActivity
    private val viewModel: ArticleDetailsViewModel by sharedViewModel()
    private lateinit var rootView: View

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        rootView = inflater.inflate(R.layout.article_details_fragment, container, false)
        setHasOptionsMenu(true)
        return rootView
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        mActivity = activity as ArticleActivity
        setBundle()
        setUpToolbar()
        getArticleDetails()
        avatarImage.setBannerImageUrl(mActivity, viewModel.selectedArticle?.avatar)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewModel.articleDetailsDataEventTrigger.postValue(Event(Unit))
    }

    private fun getArticleDetails() {
        showLoader()
        viewModel.articleDetaisDataEventTriggerEvent.observe(mActivity, articleDetailsDataObserver)
    }

    private fun goToEditArticleDetailsFragment(data: ArticleDetails?) {
        val bundle = Bundle()
        bundle.putSerializable(Constants.ARTICLE_DETAILS, data)
        Navigation.findNavController(rootView).navigate(R.id.articleDetailsEditFragment, bundle)
    }

    val articleDetailsDataObserver = Observer<Result<ArticleDetails?>> {
        if (it is Result.Loading) {

        } else {
            if (it is Result.Success) {
                viewModel.updateArticleDetails(it?.data)
                setDescription()
                hideLoader()
            }
            if (it is Result.Error) {
                hideLoader()
                ArticleUtils.handleError(mActivity, it?.exception)
            }
            if (it is Result.Failure) {
                hideLoader()
            }
        }
    }

    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        inflater?.inflate(R.menu.menu_edit, menu)
        super.onCreateOptionsMenu(menu, inflater)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val id = item?.itemId

        when (id) {
            R.id.edit -> {
                goToEditArticleDetailsFragment(viewModel.articleDetails)
                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }

    private fun setBundle(){
        val article = bundle.getSerializable(Constants.ARTICLE) as Article
        viewModel.selectArticle(article)
    }

    private fun setDescription() {
        descriptionDetails?.text = viewModel.articleDetails?.text ?: ""
    }

    private fun hideLoader() {
        progressBar?.visibility = View.GONE
    }

    private fun showLoader() {
        progressBar?.visibility = View.VISIBLE
    }

    private fun setUpToolbar() {
        mActivity?.setSupportActionBar(toolbar)
        mActivity?.supportActionBar?.title = viewModel.selectedArticle?.title ?:"Title"
        mActivity?.supportActionBar?.setDisplayHomeAsUpEnabled(true)
        mActivity?.supportActionBar?.setDisplayShowHomeEnabled(true)
        toolbar.setNavigationIcon(R.drawable.ic_back_arrow)
        toolbar.setNavigationOnClickListener {
            mActivity?.onBackPressed()
        }
    }

}