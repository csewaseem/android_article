package com.dbs.article.repository

import com.dbs.article.data.ArticleDetails
import com.dbs.article.model.Response
import retrofit2.Call
import retrofit2.await

class ArticleDetailsRespository constructor(private val weatherRepositoryService: ArticleRepositoryService) {

    suspend fun getArticleDetails(id: Int?): Response<ArticleDetails> {
        return try {
            val result = getArticleDetailsAPI(id).await()
            with(result) {
                Response.Success(this)
            }
        } catch (e: Exception) {
            Response.Error(e)
        }
    }

    private fun getArticleDetailsAPI(id: Int?): Call<ArticleDetails> {
        return weatherRepositoryService.getArticleDetails(id)
    }
}
