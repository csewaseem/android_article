package com.dbs.article.repository

import com.dbs.article.data.ArticleDetails
import com.dbs.article.data.Article
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Path

interface ArticleRepositoryService {

    @GET("/article")
    fun getArticle(): Call<List<Article>>

    @GET("/article/{id}")
    fun getArticleDetails(@Path("id") id: Int?): Call<ArticleDetails>

}