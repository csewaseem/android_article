package com.dbs.article.repository

import android.content.Context
import com.dbs.article.data.Constants
import com.dbs.article.data.RetrofitApiHelper

class ArticleServicesHelper(val context: Context) :
    RetrofitApiHelper<ArticleRepositoryService>() {

    override fun createTransactRetrofit(): ArticleRepositoryService =
        createRetrofit(Constants.BASE_URL).create(ArticleRepositoryService::class.java)
}