package com.dbs.article.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import android.widget.ImageView
import android.widget.TextView
import androidx.cardview.widget.CardView
import com.dbs.article.R
import com.dbs.article.data.Article
import com.dbs.article.extension.setBannerImageUrl
import com.dbs.article.utils.ArticleUtils


class ArticleAdapter(
    var context: Context,
    var articleList: List<Article>
) : RecyclerView.Adapter<ArticleAdapter.ViewHolder>() {

    lateinit var listener: OnItemClickListener
    override fun onCreateViewHolder(
            viewGroup: ViewGroup,
            viewType: Int
    ): ViewHolder {
        val inflater = LayoutInflater.from(viewGroup.context)
        val view = inflater.inflate(R.layout.cardview, viewGroup, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val articleList = articleList[position]
        articleList.let {
            holder.avatarImg.setBannerImageUrl(context, articleList?.avatar)
            holder.title.text = articleList?.title
            holder.date.text = ArticleUtils.formatSystemDate(articleList?.last_update, "yyyy/MM/dd")
            holder.description.text = articleList?.short_description

            holder.cardLayout.setOnClickListener {
                listener.onClick(it, articleList)
            }
        }
    }

    override fun getItemCount(): Int {
            return articleList.size
    }

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var title: TextView = itemView.findViewById(R.id.title) as TextView
        var date: TextView = itemView.findViewById(R.id.date) as TextView
        var description: TextView = itemView.findViewById(R.id.description) as TextView
        var avatarImg: ImageView = itemView.findViewById(R.id.avatarImg) as ImageView
        var cardLayout: CardView =
            itemView.findViewById(R.id.card) as CardView
    }

    interface OnItemClickListener {
        fun onClick(view: View, data: Article)
    }

    fun setOnItemClickListener(listener: OnItemClickListener) {
        this.listener = listener
    }

}