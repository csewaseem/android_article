package com.dbs.article.utils

import com.dbs.article.data.*
import com.google.gson.Gson
import java.io.BufferedReader
import java.io.FileReader
import java.io.Reader

class ArticleUtilsTest {

    private fun geArticleDetails(): Article {
        val path = "../app/assets/mocks/weather/getArticleDetails.json"
        val bufferedReader = BufferedReader(FileReader(path) as Reader?)
        return Gson().fromJson(bufferedReader, Article::class.java)
    }

}