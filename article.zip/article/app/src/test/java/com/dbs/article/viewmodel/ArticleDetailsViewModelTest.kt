package com.dbs.article.viewmodel

import android.app.Application
import androidx.arch.core.executor.testing.InstantTaskExecutorRule
import com.dbs.article.data.ArticleDetails
import com.dbs.article.di.article
import com.google.gson.Gson
import org.junit.Assert
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.koin.android.ext.koin.androidContext
import org.koin.core.context.startKoin
import org.mockito.Mock
import org.mockito.Mockito
import org.mockito.junit.MockitoJUnitRunner
import java.io.BufferedReader
import java.io.FileReader
import java.io.Reader

@RunWith(MockitoJUnitRunner::class)
class ArticleDetailsViewModelTest {

    @get:Rule
    val rule = InstantTaskExecutorRule()

    @Mock
    lateinit var articleViewModel: ArticleDetailsViewModel

    @Mock
    private lateinit var application: Application

    @Before
    fun onSetup() {
        application = Mockito.mock(Application::class.java)
        startKoin {
            // Android context
            androidContext(application)
            modules(article) }

        articleViewModel = ArticleDetailsViewModel(application)

        articleViewModel.updateArticleDetails(getArticleDetails())
    }

    private fun getArticleDetails(): ArticleDetails {
        val path = "../app/assets/mocks/article/getArticleDetails.json"
        val bufferedReader = BufferedReader(FileReader(path) as Reader?)
        return Gson().fromJson(bufferedReader, ArticleDetails::class.java)
    }

    @Test
    fun `Selected Article Details`() {
        Assert.assertEquals(getArticleDetails(), articleViewModel.articleDetails)
    }

}